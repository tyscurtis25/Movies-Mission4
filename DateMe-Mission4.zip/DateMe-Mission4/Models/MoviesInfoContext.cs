﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DateMe_Mission4.Models
{
    public class MoviesInfoContext : DbContext
    {
        //Constructor
        public MoviesInfoContext(DbContextOptions<MoviesInfoContext> options) : base(options)
        {
            //leave blank for now
        }

        public DbSet<Movies> Responses { get; set; }

        protected override void OnModelCreating(ModelBuilder mb)
        {
            mb.Entity<Movies>().HasData(

                new Movies
                {
                    MovieID = 4,
                    Category = "Action/Adventure",
                    Title = "Spider-Man: No Way Home",
                    Year = 2022,
                    Director = "Jon Watts",
                    Rating = "PG-13",
                    Edited = false,
                    Lent_to = "yeah",
                    Notes = 9

                },

                new Movies
                {
                    MovieID = 5,
                    Category = "Sports",
                    Title = "American Underdog",
                    Year = 2022,
                    Director = "Andre Erwin and Jon Erwin",
                    Rating = "PG",
                    Edited = false,
                    Lent_to = "yeah",
                    Notes = 8
                }
            );
        }
    }
}
